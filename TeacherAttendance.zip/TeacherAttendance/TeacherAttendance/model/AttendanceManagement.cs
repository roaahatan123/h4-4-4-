﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeacherAttendance.model
{
    class AttendanceManagement
    {
        private  List<Course> courses;
        private List<Teacher> teachers;
        private List<Room> rooms;
        private List<Attendance> attendance;
        public   SqlConnection Con = new SqlConnection(@"Server=DESKTOP-R4GNJVT\ALDEGAISS;Database=TeacherAttendance;Integrated Security=true");
     
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        public AttendanceManagement()
        {
            courses = new List<Course>();
            teachers = new List<Teacher>();
            rooms = new List<Room>();
            attendance = new List<Attendance>();
            fill_teachers();
            fill_room();
            fill_course();
            fill_Attend();

        }
        void fill_Attend()
        {
            

            SqlCommand cmd = new SqlCommand("SELECT * FROM View_Attendence",Con);
           

            Con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Teacher tr = new Teacher(0, dr.GetString(1));
                Course cu = new Course(0, dr.GetString(2));
                Room rm = new Room(0, dr.GetString(3));
                attendance.Add(new Attendance(dr.GetString(0),tr, cu, rm, dr.GetString(4), dr.GetString(5), dr.GetString(6)));

            }

            Con.Close();

                }
        void fill_teachers()
        {
            cmd = new SqlCommand("SELECT * FROM Teacher", Con);
            Con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                teachers.Add(new Teacher(dr.GetInt32(0), dr.GetString(1)));

            }

            Con.Close();
        }
        void fill_course()
        {
            cmd = new SqlCommand("SELECT * FROM Course", Con);
            Con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                courses.Add(new Course(dr.GetInt32(0), dr.GetString(1)));

            }

            Con.Close();
        }

        void fill_room()
        {
             cmd = new SqlCommand("SELECT * FROM Room", Con);
            Con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
          
            while (dr.Read())
               {

                rooms.Add(new Room(dr.GetInt32(0), dr.GetString(1)));

            }

            Con.Close();
        }

    

        public void addNewCourse(String CoursName)
        {
            courses.Add(new Course(courses.Count + 1, CoursName));
            cmd = new SqlCommand("insert into Course values('" + CoursName + "')", Con);
            Con.Open();
            cmd.ExecuteNonQuery();
            Con.Close();

        }

        public List<Course> getAllCourses()
        {
            List<Course> temp;

            temp = courses.GetRange(0, courses.Count);

            temp.Add(new Course(0, "Add new course..."));

            return temp;

        }

        public void addNewTeacher(String TeacherName)
        {
            teachers.Add(new Teacher(teachers.Count + 1, TeacherName));
            cmd = new SqlCommand("insert into Teacher values('" + TeacherName + "')", Con);
            Con.Open();
            cmd.ExecuteNonQuery();
            Con.Close();
        }

        public List<Teacher> getAllTeachers()
        {
            List<Teacher> temp;

            temp = teachers.GetRange(0, teachers.Count);

            temp.Add(new Teacher(0, "Add new teacher..."));

            return temp;

        }

        public void addTeacher(String TeacherName)
        {
            teachers.Add(new Teacher(teachers.Count + 1, TeacherName));
            cmd = new SqlCommand("insert into Teacher values('" + TeacherName + "')", Con);
            Con.Open();
            cmd.ExecuteNonQuery();
            Con.Close();
        }


        public void addNewRoom(String RoomName)
        {
            rooms.Add(new Room(rooms.Count + 1, RoomName));
            cmd = new SqlCommand("insert into Room values('" + RoomName + "')", Con);
            Con.Open();
            cmd.ExecuteNonQuery();
            Con.Close();
        }

        public List<Room> getAllRooms()
        {
            List<Room> temp;
            
            temp = rooms.GetRange(0, rooms.Count);

            temp.Add(new Room(0, "Add new room/lab..."));

            return temp;

        }

        public void addAttendance(
                 String attandancedate,Teacher teacher, 
                 Course course, Room room, string starttime,
                 string leavetime, string comment
        )
        {
            

            attendance.Add(new Attendance(attandancedate,teacher, course,room,
            starttime,leavetime,comment));
            cmd = new SqlCommand("insert into Attendance values('" + attandancedate+ "',"+ teacher.TeacherId + ","+ course.CourseId +","+ room .RoomId+ ",'"+ starttime + "','"+ leavetime  + "','"+ comment + "')", Con);
            Con.Open();
            cmd.ExecuteNonQuery();
            Con.Close();

        }

        public List<Attendance> getAllAttendance()
        {

            return attendance;
        }

        public Attendance getAttendanceByIndex(int index)
        {

            return attendance[index];
        }


        public void editAttendance(
              String attandancedate, Teacher teacher,
              Course course, Room room, string starttime,
              string leavetime, string comment,int index
     )
        {


            attendance[index]=(new Attendance(attandancedate, teacher, course, room,
            starttime, leavetime, comment));


        }



    }





}
